import java.awt.event.ActionEvent;
import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;




public class WestminsterSkinConsultationManager implements SkinConsultationManager {


    private static final int maxDoctor = 10; //the maximum number of doctors that can be added into the system
    Scanner input = new Scanner(System.in);//asking for inputs form the user
    static ArrayList<Doctor> doctorArrayList = new ArrayList<>();// to save the doctor's details in an arraylist


    @Override
    public void addDoc() { //adding the doctor into the system

        if (doctorArrayList.size() == maxDoctor) {
            System.out.println("The system has reached its maximum limit, try deleting doctors to add again");

            while (true) {
                System.out.println("\nWould you like to delete a doctor? (Yes/No)");
                String conditionInput = input.nextLine();

                switch (conditionInput.toUpperCase()) {
                    case ("YES"):
                        deleteDoc();
                        break;
                    case ("NO"):
                        break;
                    default:
                        System.out.println("\nIncorrect Input, TRy again da sunni\n");
                        continue;
                }

                break;
            }

        } else {
            System.out.print("Enter the first name of the doctor:");
            String name = input.nextLine(); //retrieving inputs from the user

            System.out.print("Enter the  surname of the doctor:");
            String surName = input.nextLine();//retrieving inputs from the user

            System.out.print("Enter the license number of the doctor: ");
            String licenseNum = input.nextLine();//retrieving inputs from the user

            System.out.print("Enter the specialisation of the doctor: ");
            String specialisation = input.nextLine();//retrieving inputs from the user

            System.out.print("Enter the name of the hospital: ");
            String hospitalName = input.nextLine();//retrieving inputs from the user

            String DOB = null;

            Doctor doctorObj = new Doctor(name, surName, licenseNum, specialisation, hospitalName, DOB);

            doctorArrayList.add(doctorObj);
            System.out.println("\n---THE DOCTORS HAS BEEN SUCCESSFULLY ADDED INTO THE SYSTEM---\n");
            System.out.println((10-doctorArrayList.size())+" more doctors can be added into the system.");// to display the range of doctors that can be added into the system
        }
    }

    @Override
    public void deleteDoc() {

        System.out.println("");

        while (true) {

            for (Doctor doctor : doctorArrayList) {

                System.out.println("Name: " + doctor.getName() + " " + doctor.getSurName());
                System.out.println("License number: " + doctor.getMedLicenseNum() + "\n");
            }


            System.out.println("Enter the doctors license number that you wish to wipe out (enter anything else to exit):");
            String deleteOption = input.nextLine(); // asks the user for the correct license number

            for (Doctor doctor : doctorArrayList) {
                if (doctor.getMedLicenseNum().equalsIgnoreCase(deleteOption)) {
                    System.out.println("Are you sure you want to delete " + doctor.getName() + " " + doctor.getSurName() + " (yes/no)?");//this condition is to make sure that the user wishes to deleted the doctor from the system
                    String userInput = input.nextLine();


                    if (userInput.equalsIgnoreCase("Yes")) {//condition to remove the doctor
                        doctorArrayList.remove(doctor);
                        System.out.println("THE DOCTOR HAS BEEN SUCCESSFULLY REMOVED");
                        break;
                    } else if (userInput.equalsIgnoreCase("NO")) {
                        break; // the loop will be broken if the user changes their mind
                    }
                }
            }
            break;
        }
        System.out.println("\nThe number of doctors in the system are:" + doctorArrayList.size());

    }


    @Override
    public void printDoc() { // the sorted doctor details will be displayed through this constructor.
        if (doctorArrayList.size() == 0) {
            System.out.println("\n----------There are no doctors entered into the system-----------");
        }
        sortDoctor();
        for (Doctor doctor : doctorArrayList) {//loop to display all the doctors that have been sorted

            System.out.println("\nName: " + doctor.getName());
            System.out.println("Surname: " + doctor.getSurName());
            System.out.println("License number: " + doctor.getMedLicenseNum());
            System.out.println("Specialisation: " + doctor.getMedSpecialisation());
            System.out.println("Hospital: " + doctor.getHospitalName());
        }
    }


    protected static void sortDoctor() { // this will iterated through the surnames of the doctors and sort them accordingly
        Collections.sort(doctorArrayList, new Comparator<Doctor>() {
            public int compare(Doctor o1, Doctor o2) {
                return o1.getSurName().toUpperCase().compareTo(o2.getSurName().toUpperCase());
            }
        });
    }


    @Override
    public void saveList() throws IOException {//this will save the doctors details in the text file so that it can be retrieved and manipulated later

        File file = new File("DoctorList.txt");
        FileOutputStream fout = new FileOutputStream(file);
        ObjectOutputStream objout = new ObjectOutputStream(fout);


        for (Doctor doctor : doctorArrayList) {
            objout.writeObject(doctor);

        }
        objout.flush();
        fout.close();
        objout.close();

        System.out.println("\n The details have been saved in the text file.\n");
    }


    public void loadList() throws IOException { //this constructor will open the display the existent doctors in the text file
        FileInputStream fit = new FileInputStream("DoctorList.txt");
        ObjectInputStream oit = new ObjectInputStream(fit);


        System.out.println("\n--------The doctors in the lists-----------");
        while (true) {
            try {
                Doctor doctor = (Doctor) oit.readObject();
                doctorArrayList.add(doctor);
                System.out.println("First name: "+doctor.getName());
            } catch (EOFException | ClassNotFoundException e) {
                break;
            }
        }
        fit.close();
        oit.close();



    }


    public ActionEvent GUI() throws IOException {
        //saveFile();
        new GUI();
        return null;
    }

}

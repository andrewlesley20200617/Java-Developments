import java.util.Date;

public class Consultation {

    private Doctor doctor;
    private String date;
    private String time;
    private String cost;
    private String notes;



    // the getter methods for this class
    public String getDate(){
        return date;
    }
    private String getTime(){
        return time;
    }
    public String getCost(){
        return cost;
    }
    public String getNotes(){
        return notes;
    }


    // the setter methods for this class
    public void setDate(String date){
        this.date = date;
    }
    public void setTime(String time){
        this.time =time;
    }
    public void setCost(String cost){
        this.cost = cost;
    }
    public void setNotes(String notes){
        this.notes = notes;
    }


}

public class Patient extends Person{

   private String patientNUm;
   private String patientNIC;
   private String DocName;
   private String channeldate;
   private String channelingTime;
   private String channelDuration;
   private String firstTime;
   private int fee;




    public Patient(String name, String surname, String DOB, String patientNum, String patientNIC, String DocName, String channeldate, String channelingTime, String channelDuration, String firstTime, int fee) {
        super(name, surname,DOB);
        this.patientNUm=patientNum;
        this.patientNIC= patientNIC;
        this.DocName =DocName;
        this.channeldate = channeldate;
        this.channelingTime = channelingTime;
        this.channelDuration = channelDuration;
        this.firstTime = firstTime;
        this.fee = fee;

    }

    public String getFirstTime() {
        return firstTime;
    }

    public void setFirstTime(String firstTime) {
        this.firstTime = firstTime;
    }


    public String getPatientNUm() {
        return patientNUm;
    }

    public void setPatientNUm(String patientNUm) {
        this.patientNUm = patientNUm;
    }

    public String getPatientNIC() {
        return patientNIC;
    }

    public void setPatientNIC(String patientNIC) {
        this.patientNIC = patientNIC;
    }

    public String getDocName() {
        return DocName;
    }

    public void setDocName(String docName) {
        DocName = docName;
    }

    public String getChanneldate() {
        return channeldate;
    }

    public void setChanneldate(String channeldate) {
        this.channeldate = channeldate;
    }

    public String getChannelingTime() {
        return channelingTime;
    }

    public void setChannelingTime(String channelingTime) {
        this.channelingTime = channelingTime;
    }

    public String getChannelDuration() {
        return channelDuration;
    }

    public void setChannelDuration(String channelDuration) {
        this.channelDuration = channelDuration;
    }
}




import com.toedter.calendar.JDateChooser;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.lang.Object;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;


public class GUI extends WestminsterSkinConsultationManager  implements ActionListener {

    private int consultationFee;

   private String yesNO;
   private int duration;
   int fee =duration*consultationFee;

   private JScrollPane scrollPane  = new JScrollPane();
    JDateChooser date = new JDateChooser();//get the date from the user in a more visual manner
    JDateChooser patientDOB= new JDateChooser();//get the date from the user in a more visual manner
    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy"); // optimising the date to this format


   // all the frames in the gui console that displays all the buttons,labels,panels and many more
    private final JFrame frame1 = new JFrame();
    private final JFrame frame2 = new JFrame();
    private final JFrame frame3 = new JFrame();
    private final JFrame frame4 = new JFrame();
    private final JFrame frame6 = new JFrame();
    private  final JFrame consultaionFrame = new JFrame();
    private JFrame consultationDetailsFrame = new JFrame();
    private final JRadioButton yesButton = new JRadioButton("YES");
    private final JRadioButton noButton = new JRadioButton("NO");

    private JRadioButton oneHourButton = new JRadioButton("1 HOUR");
    private JRadioButton twoHourButton = new JRadioButton("2 HOURS");
    private JRadioButton threeHourButton = new JRadioButton("3 HOURS");

    //panels to be inseted into the frame and maintain a proper layout throughout the gui system
    private JPanel panel1 = new JPanel();
    private JPanel panel2 = new JPanel();
    private JPanel panel3 = new JPanel();
    private JPanel panel4 = new JPanel();
    private JPanel panel5 = new JPanel();
    private JPanel panel6 = new JPanel();
    private JPanel panel7 = new JPanel();
    private JPanel panel8 = new JPanel();
    private JPanel panelInfo = new JPanel();


    // the labels to direct the user to perform certains actions and get an insght of the details in the frame
    private JLabel label1 = new JLabel();
    private JLabel label2 = new JLabel();
    private JLabel label3 = new JLabel();
    private JLabel label4 = new JLabel();
    private JLabel label5 = new JLabel();
    private JLabel label6 = new JLabel();
    private JLabel label7 = new JLabel();
    private JLabel label8 = new JLabel();
    private JLabel label9 = new JLabel();
    private JLabel label10 = new JLabel();
    private JLabel doctorFirstName = new JLabel();
    private JLabel docChannelDate = new JLabel();
    private JLabel docChannelingTime = new JLabel();
    private JLabel docChannelingDuration = new JLabel();
    private  JLabel patientFirstName = new JLabel();
    private  JLabel patientSurNameLabel= new JLabel();
    private  JLabel patientBirthLabel = new JLabel();
    private JLabel patientNumLabel = new JLabel();
    private JLabel patientIdentityLabel = new JLabel();
    private JLabel yesNOLabel = new JLabel();
    private JLabel consultationFeePanel = new JLabel();

    // buttons to add event listened and interactions throughout the gui system
    private JButton viewDoctorListButton = new JButton();
    private JButton channelDoctorButton = new JButton();
    private JButton sortDoctorButton  = new JButton();
    private JButton consultationListButton = new JButton();
    private JButton backDoctorButton = new JButton();
    private JButton nextButton = new JButton();
    private JButton backdoctorbutton1 = new JButton();
    private JButton backButton2 = new JButton();
    private JButton continueButton = new JButton();
    private JButton saveButton = new JButton();
    private JButton mainMenuButton = new JButton();



    //textfirls is used to get text input from the user
    private JTextField firstName = new JTextField();
    private JTextField surName = new JTextField();
    private JTextField phoneNumber = new JTextField();
    private JTextField nicNumber = new JTextField();

    private  String[] docOptionFName = new String[10];
    static ArrayList<Patient> patientDetailList = new ArrayList<>();

    private
    JComboBox comboBox;
    JComboBox channelTime;

    private String docName;
    private String channelDate ;
    private String channelingTime ;
    private String channelDuration;
    private String patientName ;
    private String patientsSurName ;
    private String patientBirth;
    private String patientNum;
    private String patientIdentity ;


    public GUI() { //this is the main frame of the system and will be appear when the user enters and input to open the gui from the console
        // button to let the user visualise the doctor's details.
        viewDoctorListButton.setBounds(150, 250,500, 100);
        viewDoctorListButton.addActionListener(this);
        viewDoctorListButton.setText("VIEW DOCTORS");
        viewDoctorListButton.setBackground(Color.darkGray);
        viewDoctorListButton.setForeground(Color.white);
        viewDoctorListButton.setFocusable(false);

        //button to let the user channel an appointment with the doctor available
        channelDoctorButton.setBounds(150,375,500,100);
        channelDoctorButton.setBackground(Color.darkGray);
        channelDoctorButton.setForeground(Color.white);
        channelDoctorButton.setText("CHANNEL DOCTOR");
        channelDoctorButton.addActionListener(this);
        channelDoctorButton.setFocusable(false);

        consultationListButton.setBounds(150,500,500,100);
        consultationListButton.setBackground(Color.darkGray);
        consultationListButton.setForeground(Color.white);
        consultationListButton.setText("CONSULTATION LIST");
        consultationListButton.addActionListener(this);
        consultationListButton.setFocusable(false);

        // the frame that is being created for the first panel in the GUI
        frame1.setSize(800, 800);// the dimensions of the frame
        frame1.setTitle("Graphical User Interface");
        frame1.getContentPane().setBackground(Color.BLACK);// the background color of the frame
        frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame1.add(viewDoctorListButton);
        frame1.add(channelDoctorButton);
        frame1.add(consultationListButton);
        frame1.setLayout(null);
        frame1.setLocationRelativeTo(null); // this will let the frame appear in the middle of the screen
        frame1.setVisible(true);// make the frame visible and active

    }

    public ActionListener doctorDetailsTable() { //
        frame2.setLayout(new BorderLayout(0,0));

        //table model to display the table of doctors and their details.
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Number");
        model.addColumn("Name");
        model.addColumn("Surname");
        model.addColumn("License Number");
        model.addColumn("Specialisation");
        model.addColumn("Hospital");

        // the for loop to iterate and print all the doctors in the system
        for (int i = 0; i < doctorArrayList.size(); i++) {
            Doctor doctor = doctorArrayList.get(i);
            model.addRow(new Object[]{i+1,
                    doctor.getName(),
                    doctor.getSurName(),
                    doctor.getMedLicenseNum(),
                    doctor.getMedSpecialisation(),
                    doctor.getHospitalName()});}

        JTable table = new JTable(model);
        JScrollPane scrollpane = new JScrollPane(table);
        scrollpane.setPreferredSize(new Dimension(700, 250));
        table.setRowHeight(20);
        table.setEnabled(false);//makes the table cells uneditable
       // table.setMinimumSize(new Dimension(600,200));

        sortDoctorButton.setSize(300,50);
        sortDoctorButton.addActionListener(this);
        sortDoctorButton.setText("SORT");
        sortDoctorButton.setFocusable(false);
        sortDoctorButton.setBackground(Color.darkGray);
        sortDoctorButton.setForeground(Color.white);
        sortDoctorButton.setPreferredSize(new Dimension(150,50));

        backDoctorButton.addActionListener((this));
        backDoctorButton.setText("BACK");
        backDoctorButton.setFocusable(false);
        backDoctorButton.setBackground(Color.darkGray);
        backDoctorButton.setForeground(Color.red);
        backDoctorButton.setPreferredSize(new Dimension(150,50));

        channelDoctorButton.setPreferredSize(new Dimension(150,50));
        channelDoctorButton.setForeground(Color.green);

        panel1.add(scrollpane,BorderLayout.CENTER);
        panel1.setSize(700,460);
        panel1.setBackground(Color.black);

        panel5.setBackground(Color.black);
        panel5.add(backDoctorButton);
        panel5.add(sortDoctorButton);
        panel5.add(channelDoctorButton);

        frame2.add(panel1);
        frame2.add(panel5,BorderLayout.SOUTH);
        frame2.setBackground(Color.black);// the background color of the frame
        frame2.setSize(800, 550);// the dimensions of the frame
        frame2.setTitle("Doctors List");// the title of the frame
        frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);// the program will end once the frame is closed
        frame2.setLocationRelativeTo(null); // this will let the frame appear in the middle of the screen
        frame2.setVisible(true);// make the frame visible and active
        return null;
    }

    public ActionListener sortedTable(){ //this frame will be visible once the user enters the sort button
        frame6.setLayout(new BorderLayout(0,0));

        Collections.sort(doctorArrayList, new Comparator<Doctor>() {
            public int compare (Doctor q1,Doctor q2){
                return q1.getSurName().toUpperCase().compareTo(q2.getSurName().toUpperCase());
            }
        });

        try {
            saveList();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        //table model to display the table of doctors and their details.
        DefaultTableModel model1 = new DefaultTableModel();
        model1.addColumn("Number");
        model1.addColumn("Name");
        model1.addColumn("Surname");
        model1.addColumn("License Number");
        model1.addColumn("Specialisation");
        model1.addColumn("Hospital");

        // the for loop to iterate and print all the doctors in the system
        for (int i = 0; i < doctorArrayList.size(); i++) {
            Doctor doctor = doctorArrayList.get(i);
            model1.addRow(new Object[]{i+1,
                    doctor.getName(),
                    doctor.getSurName(),
                    doctor.getMedLicenseNum(),
                    doctor.getMedSpecialisation(),
                    doctor.getHospitalName()});}


        JTable docTable = new JTable(model1);
        JScrollPane scrollpane = new JScrollPane(docTable);
        scrollpane.setPreferredSize(new Dimension(700, 250));
        docTable.setRowHeight(20);
        docTable.setEnabled(false);//makes the table cells uneditable
        // table.setMinimumSize(new Dimension(600,200));

        panel7.add(scrollpane,BorderLayout.CENTER);
        panel7.setSize(700,460);
        panel7.setBackground(Color.black);

        panel8.setBackground(Color.black);
        panel8.add(backDoctorButton); //buttons being added to the panel
        panel8.add(sortDoctorButton);//buttons being added to the panel
        panel8.add(channelDoctorButton);//buttons being added to the panel

        frame6.add(panel7);// panel being added to the frame
        frame6.add(panel8,BorderLayout.SOUTH);// panel being added to the frame
        frame6.setBackground(Color.black);// the background color of the frame
        frame6.setSize(800, 550);// the dimensions of the frame
        frame6.setTitle("Doctors List");// the title of the frame
        frame6.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);// the program will end once the frame is closed
        frame6.setLocationRelativeTo(null); // this will let the frame appear in the middle of the screen
        frame6.setVisible(true); // make the frame visible and active

        return null;
    }

    public ActionListener channelDoctor(){

            String timeSlot[] = {"7:00 AM", "8:00 AM", "9:00 AM", "10:00 AM", "11:00 AM",
                    "12:00 PM", "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM"};



            for (int i = 0; i < doctorArrayList.size(); i++) {
                String docName = doctorArrayList.get(i).getName();
                docOptionFName[i] = docName;
            }
            label1.setText("Choose your doctor:");
            label1.setBounds(100, 20, 200, 30);
            label2.setText("Choose the date:");
            label2.setBounds(100, 120, 200, 30);
            label2.setBackground(Color.BLACK);
            label3.setText("Select time:");
            label3.setBounds(100, 220, 200, 30);
            label9.setText("Duration of the consultation: ");
            label9.setBounds(100, 320, 200, 30);
            label8.setText("Is this your first time booking?");
            label8.setBounds(100, 470, 200, 30);

            comboBox = new JComboBox(docOptionFName);
            comboBox.addActionListener(this);
            comboBox.setEditable(false);
            comboBox.setBounds(300, 20, 200, 30);
            comboBox.setSelectedIndex(-1);

            label1.setForeground(Color.white);
            label2.setForeground(Color.white);
            label3.setForeground(Color.white);
            label8.setForeground(Color.white);
            label9.setForeground(Color.white);

            date.setBounds(300, 120, 200, 30);

            channelTime = new JComboBox(timeSlot);
            channelTime.addActionListener(this);
            channelTime.setEditable(false);
            channelTime.setBounds(300, 220, 200, 30);
            channelTime.setSelectedIndex(-1);

            yesButton.setBounds(300, 500, 100, 30);
            yesButton.setBackground(Color.black);
            yesButton.setForeground(Color.white);
            yesButton.setFocusable(false);
            yesButton.addActionListener(this);

            noButton.setBounds(400, 500, 100, 30);
            noButton.setBackground(Color.black);
            noButton.setForeground(Color.white);
            noButton.setFocusable(false);
            noButton.addActionListener(this);

            ButtonGroup bg1 = new ButtonGroup();
            bg1.add(yesButton);
            bg1.add(noButton);

            ButtonGroup bg2 = new ButtonGroup();
            bg2.add(oneHourButton);
            bg2.add(twoHourButton);
            bg2.add(threeHourButton);

            oneHourButton.setBounds(200, 400, 100, 30);
            oneHourButton.setBackground(Color.black);
            oneHourButton.setForeground(Color.white);
            oneHourButton.setFocusable(false);
            oneHourButton.addActionListener(this);

            twoHourButton.setBounds(350, 400, 100, 30);
            twoHourButton.setBackground(Color.black);
            twoHourButton.setForeground(Color.white);
            twoHourButton.setFocusable(false);
            twoHourButton.addActionListener(this);

            threeHourButton.setBounds(500, 400, 100, 30);
            threeHourButton.setBackground(Color.black);
            threeHourButton.setForeground(Color.white);
            threeHourButton.setFocusable(false);
            threeHourButton.addActionListener(this);

            panel2.setLayout(null);
            panel2.add(label1);
            panel2.add(comboBox);
            panel2.add(label2);
            panel2.add(date);
            panel2.add(label3);
            panel2.add(channelTime);
            panel2.add(label8);
            panel2.add(label9);
            panel2.add(oneHourButton);
            panel2.add(twoHourButton);
            panel2.add(threeHourButton);
            panel2.add(yesButton);
            panel2.add(noButton);
            panel2.setBackground(Color.black);

            backdoctorbutton1.setText("BACK");
            backdoctorbutton1.addActionListener(this);
            backdoctorbutton1.setForeground(Color.red);
            backdoctorbutton1.setBackground(Color.darkGray);
            backdoctorbutton1.setFocusable(false);
            backdoctorbutton1.setPreferredSize(new Dimension(150, 50));

            nextButton.setText("CONTINUE");
            nextButton.addActionListener(this);
            nextButton.setForeground(Color.green);
            nextButton.setBackground(Color.darkGray);
            nextButton.setFocusable(false);
            nextButton.setPreferredSize(new Dimension(150, 50));

            viewDoctorListButton.setPreferredSize(new Dimension(150, 50));

            panel3.setBackground(Color.black);
            panel3.add(backdoctorbutton1);
            panel3.add(viewDoctorListButton);
            panel3.add(nextButton);

            frame3.setLayout(new BorderLayout(70, 0));
            frame3.add(panel2, BorderLayout.CENTER);
            frame3.add(panel3, BorderLayout.SOUTH);
            frame3.setSize(700, 700);// the dimensions of the frame
            frame3.setTitle("Select Doctor");// the title of the frame
            frame3.setLocationRelativeTo(null); // this will let the frame appear in the middle of the screen
            frame3.setDefaultCloseOperation(frame3.EXIT_ON_CLOSE);// the program will end once the frame is closed
            frame3.setVisible(true);// make the frame visible and active

            return null;
    }


    public ActionListener patientDetails(){

        frame4.setLayout(new BorderLayout(0,0));

        label4.setText("Enter your first name:");
        label4.setBounds(50,50,200,30);

        label5.setText("Enter you surname:");
        label5.setBounds(50,150,200,30);

        label6.setText("Date of birth");
        label6.setBounds(50,250,200,30);

        label7.setText("Mobile Number");
        label7.setBounds(50,350,200,30);

        label8.setText("Identity Number");
        label8.setBounds(50,450,200,30);

        panel4.setBounds(50,50,400,500);
        panel4.setLayout(null);

        firstName.setBounds(200,50,200,30);
        surName.setBounds(200,150,200,30);
        patientDOB.setBounds(200,250,200,30);
        phoneNumber.setBounds(200,350,200,30);
        nicNumber.setBounds(200,450,200,30);

        panel4.add(label4);
        panel4.add(label5);
        panel4.add(label6);
        panel4.add(label7);
        panel4.add(label8);

        panel4.add(firstName);
        panel4.add(surName);
        panel4.add(patientDOB);
        panel4.add(phoneNumber);
        panel4.add(nicNumber);
        panel4.setBackground(Color.black);

        //button to direct to the previous frame
        backButton2.setText("BACK");
        backButton2.addActionListener(this);
        backButton2.setForeground(Color.red);
        backButton2.setBackground(Color.darkGray);
        backButton2.setFocusable(false);
        backButton2.setPreferredSize(new Dimension(150, 50));

        //button to direct to the next frame
        continueButton.setText("CONTINUE");
        continueButton.addActionListener(this);
        continueButton.setForeground(Color.green);
        continueButton.setBackground(Color.darkGray);
        continueButton.setFocusable(false);
        continueButton.setPreferredSize(new Dimension(150, 50));

        label4.setForeground(Color.white);
        label5.setForeground(Color.white);
        label6.setForeground(Color.white);
        label7.setForeground(Color.white);
        label8.setForeground(Color.white);

        panel6.add(backButton2);
        panel6.add(continueButton);
        panel6.setBackground(Color.black);

        frame4.add(panel4,BorderLayout.CENTER);
        frame4.add(panel6,BorderLayout.SOUTH);
        frame4.setSize(700,600);// the dimensions of the frame
        frame4.setTitle("Patient Details");// the title of the frame
        frame4.setLocationRelativeTo(null); // this will let the frame appear in the middle of the screen
        frame4.setDefaultCloseOperation(frame4.EXIT_ON_CLOSE);// the program will end once the frame is closed
        frame4.setVisible(true);// make the frame visible and active

        return null;
    }

    public void textValidation(){ // to check if the text fields have been filled by the user if not an error is to appear

        date.setDateFormatString("dd-MM-yyyy");
        patientDOB.setDateFormatString("dd-MM-yyyy");

        docName = comboBox.getSelectedItem().toString(); //variable to save the doctors name
        channelDate =  sdf.format(date.getDate());//variable to save the consultation date
        channelingTime = channelTime.getSelectedItem().toString();//variable to save the consultation time
        patientName = firstName.getText();//variable to save the patients first name
        patientsSurName = surName.getText();// vatiable to save the surname of the patient
        patientBirth =  sdf.format(patientDOB.getDate());//variable to save the date of birth of the patient
        patientNum = phoneNumber.getText();//variable to savd the phone number of the patient.
        patientIdentity = nicNumber.getText();//variable to save the nic number of the patient

        if(patientName.equals("")) { // conditions to check if the textfields are empty (null) or not and display an error message in regardsn\
            JOptionPane.showMessageDialog(null, "Please enter your first name", "Type Error", JOptionPane.ERROR_MESSAGE);
        }
         else if(patientsSurName.equals("")){
            JOptionPane.showMessageDialog(null, "Please enter your  surname", "Type Error", JOptionPane.ERROR_MESSAGE);
        }
        else if (patientBirth.equals("")){
            JOptionPane.showMessageDialog(null, "Please enter you Date of birth", "Type Error", JOptionPane.ERROR_MESSAGE);
        }
         else if (patientNum.equals("")){
            JOptionPane.showMessageDialog(null, "Please enter you Phone Number", "Type Error", JOptionPane.ERROR_MESSAGE);
        }
        else if (patientIdentity.equals("")){
            JOptionPane.showMessageDialog(null, "Please enter you NIC number", "Type Error", JOptionPane.ERROR_MESSAGE);
        }
        else {
            channelInfo();
        }
    }

    /*public void doctorCondition(){


        for (Patient patient : patientDetailList) {
            if (docName.equals(patient.getDocName()) &&  channelDate.equals(patient.getChanneldate())  && channelingTime.equals(patient.getChannelingTime())) {
                JOptionPane.showMessageDialog(null, "Doctor is not available", "Doctor Availability", JOptionPane.PLAIN_MESSAGE);

            }
        }
        patientDetails();
    }*/

    public void channelInfo(){ // this constructor will allows the patient to visualise their cosultation with all the required details

        panelInfo.setLayout(new BorderLayout());

        patientFirstName.setText("Patient First Name:            "+patientName); // patient's name in the consultation
        patientFirstName.setBounds(200,50,500,20);
        patientFirstName.setForeground(Color.white);

        patientSurNameLabel.setText("Patient Surname:            "+patientsSurName);// patient's surname in the consultation
        patientSurNameLabel.setBounds(200,100,500,20);
        patientSurNameLabel.setForeground(Color.white);

        patientBirthLabel.setText("Patient Date of Birth:        "+patientBirth);// patients date of birth
        patientBirthLabel.setBounds(200,150,500,20);
        patientBirthLabel.setForeground(Color.white);

        patientNumLabel.setText("Patient Contact Number:         "+patientNum);//patients contact number
        patientNumLabel.setBounds(200,200,500,20);
        patientNumLabel.setForeground(Color.white);

        patientIdentityLabel.setText("Patient NIC Number:        "+patientIdentity);//patients nic number
        patientIdentityLabel.setBounds(200,250,500,20);
        patientIdentityLabel.setForeground(Color.white);

        doctorFirstName.setText("Doctor's first name:            "+docName);// the doctors name that the patient has chosen to consult
        doctorFirstName.setBounds(200,300,500,20);
        doctorFirstName.setForeground(Color.white);

        docChannelDate.setText("Consultation date:               "+channelDate);//the consultation date
        docChannelDate.setBounds(200,350,500,20);
        docChannelDate.setForeground(Color.white);

        docChannelingTime.setText("Consultation time:            "+channelingTime); //the consultation time
        docChannelingTime.setBounds(200,400,500,20);
        docChannelingTime.setForeground(Color.white);

        docChannelingDuration.setText("Consultation duration:    "+channelDuration+" HR(S)"); // the duration of the consultation
        docChannelingDuration.setBounds(200,450,200,20);
        docChannelingDuration.setForeground(Color.white);

        yesNOLabel.setText("First time Consultation:      "+ yesNO);// to check if it is the first time that the patient is chanelling
        yesNOLabel.setBounds(200,500,200,20);
        yesNOLabel.setForeground(Color.white);

        consultationFeePanel.setText("Consultation fee:   "+duration*consultationFee);// depending on the first time the consultation fee will vary
        consultationFeePanel.setBounds(200,550,200,20);
        consultationFeePanel.setForeground(Color.white);

        label10.setBounds(200,600,200,20);

        panelInfo.setBackground(Color.black);
        panelInfo.setSize(700,600);
        panelInfo.add(patientFirstName);
        panelInfo.add(patientSurNameLabel);
        panelInfo.add(patientBirthLabel);
        panelInfo.add(patientNumLabel);
        panelInfo.add(patientIdentityLabel);
        panelInfo.add(doctorFirstName);
        panelInfo.add(docChannelDate);
        panelInfo.add(docChannelingTime);
        panelInfo.add(docChannelingDuration);
        panelInfo.add(yesNOLabel);
        panelInfo.add(consultationFeePanel);
        panelInfo.add(label10);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(Color.black);
        buttonPanel.add(saveButton,BorderLayout.SOUTH);

        saveButton.setPreferredSize(new Dimension(150,50));
        saveButton.setText("SAVE");
        saveButton.addActionListener(this);
        saveButton.setForeground(Color.green);
        saveButton.setBackground(Color.darkGray);
        saveButton.setFocusable(false);

        consultaionFrame.add(panelInfo,BorderLayout.CENTER);
        consultaionFrame.add(buttonPanel,BorderLayout.SOUTH);
        consultaionFrame.setSize(700,800);// the dimensions of the frame
        consultaionFrame.setTitle("Consultation Information");// the title of the frame
        consultaionFrame.setLocationRelativeTo(null); // this will let the frame appear in the middle of the screen
        consultaionFrame.setDefaultCloseOperation(frame4.EXIT_ON_CLOSE);// the program will end once the frame is closed
        consultaionFrame.setVisible(true);// make the frame visible and active
    }
    public void consultationDetails(){
        Patient patientOBj = new Patient(patientName,patientsSurName,patientBirth,
                patientNum,patientIdentity,docName,channelDate,channelingTime,channelDuration,yesNO,fee);

        patientDetailList.add(patientOBj);

        mainMenuButton.setPreferredSize(new Dimension(150,50));
        mainMenuButton.setText("MAIN MENU");
        mainMenuButton.addActionListener(this);
        mainMenuButton.setForeground(Color.white);
        mainMenuButton.setBackground(Color.darkGray);
        mainMenuButton.setFocusable(false);

        JPanel consultationDetailPanel = new JPanel();

        //table model to display the table of doctors and their details.
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Name");
        model.addColumn("Surname");
        model.addColumn("Birth");
        model.addColumn("Number");
        model.addColumn("Identity");
        model.addColumn("Doctor Name");
        model.addColumn("Date");
        model.addColumn("Time ");
        model.addColumn("Duration");
        model.addColumn("First Time");

        // the for loop to iterate and print all the doctors in the system
        for (Patient patient : patientDetailList) {
            model.addRow(new Object[]{
                    patient.getName(),
                    patient.getSurName(),
                    patient.getDOB(),
                    patient.getPatientNUm(),
                    patient.getPatientNIC(),
                    patient.getDocName(),
                    patient.getChanneldate(),
                    patient.getChannelingTime(),
                    patient.getChannelDuration() + " HRS",
                    patient.getFirstTime(),
            });
        }

        JTable table = new JTable(model);
        table.setEnabled(false);//makes the table cells uneditable

        JScrollPane scrollpane = new JScrollPane(table);
        scrollpane.setPreferredSize(new Dimension(1000, 300));
        table.setRowHeight(20);

        consultationDetailPanel.add(scrollpane);
        consultationDetailPanel.setBackground(Color.black);

        consultationDetailsFrame.add(consultationDetailPanel,BorderLayout.CENTER);
        consultationDetailsFrame.add(mainMenuButton, BorderLayout.SOUTH);
        consultationDetailsFrame.setSize(1200,700);// the dimensions of the frame
        consultationDetailsFrame.setTitle("Patient Consultation Details");// the title of the frame
        consultationDetailsFrame.setLocationRelativeTo(null); // this will let the frame appear in the middle of the screen
        consultationDetailsFrame.setDefaultCloseOperation(frame4.EXIT_ON_CLOSE);// the program will end once the frame is closed
        consultationDetailsFrame.setVisible(true);// make the frame visible and active
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == viewDoctorListButton) {
            frame1.dispose();
            doctorDetailsTable();
        }
        else if(e.getSource() == channelDoctorButton){
            channelDoctor();
            frame1.dispose();
        }
        else if (e.getSource()== comboBox){
            System.out.println(comboBox.getSelectedItem());
        }
        else if(e.getSource() == backDoctorButton){
            try {
                GUI();
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
            frame2.dispose();
            frame1.dispose();
        }
        else if(e.getSource()==nextButton){
            frame2.dispose();
            frame3.dispose();
            frame1.dispose();
            //doctorCondition();
            patientDetails();

        }
        else if(e.getSource()==sortDoctorButton){
            frame2.dispose();
            sortedTable();
        }
        else if(e.getSource()==backdoctorbutton1){
            frame3.dispose();
            try {
                GUI();
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        }
        else if( e.getSource()==backButton2){
            frame4.dispose();
            channelDoctor();
        }
        else if (e.getSource() == continueButton){
            textValidation();

        }
        else if (e.getSource() ==saveButton ){
            consultationDetails();
        }
        else if(e.getSource()== mainMenuButton){
            try {
                GUI();
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        }
        else if(e.getSource()==consultationListButton){
            consultationDetails();
        }
        else if(e.getSource()==yesButton){
            yesNO ="YES";
            consultationFee = 15;
        }
        else if(e.getSource() == noButton){
            yesNO = "NO";
            consultationFee =25;
        }
        else if(e.getSource() == oneHourButton){
            channelDuration = "1";
            duration = 1;
        }
        else if(e.getSource() == twoHourButton){
            channelDuration = "2";
            duration=2;
        }
        else if(e.getSource() == threeHourButton){
            channelDuration = "3";
            duration=3;
        }

    }
}






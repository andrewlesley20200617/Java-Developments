

public class Doctor extends Person{

    private String licenseNum;
    private String specialisation;
    private String docSalary;
    private String hospitalName;



    public Doctor(String name, String surName,
                  String licenseNum,String specialisation, String hospitalName,String DOB) {
        super(name, surName,DOB);
        this.licenseNum = licenseNum;
        this.specialisation = specialisation;
        this.hospitalName = hospitalName;
    }


    // the getter method for the doctor class
    public String getMedLicenseNum(){
        return licenseNum;
    }
    public String getMedSpecialisation(){
        return specialisation;
    }
    public String getDocSalary(){
        return docSalary;
    }
    public String getHospitalName(){
        return hospitalName;
    }



    // the setter method for the doctor class
    public void setMedLicenseNum(String licenseNum){
        this.licenseNum = licenseNum;
    }
    public void setMedSpecialisation(String specialisation){
        this.specialisation = specialisation;
    }
    public void setdocSalary(String docSalary){
        this.docSalary = docSalary;
    }
    public void setHospitalName(String hospitalName){
        this.hospitalName = hospitalName;
    }



    public String toString(){
        return licenseNum+" "+specialisation+" "+docSalary+" "+hospitalName;
    }


}








import java.io.Serializable;

abstract class Person implements Serializable {
    //initiating the instance variables
    private String name;
    private String surName;
    private String DOB;
    private String mobNumber;
    private String email;
    private String sex;


    public Person(String name, String surName,String DOB) {
        this.DOB = DOB;
        this.name = name;
        this.surName= surName;
    }



    //the getter methods of the variable.
    public String getName(){
        return name;
    }
    public String getSurName(){
        return surName;
    }
    public String getDOB(){
        return DOB;
    }
    public String getMobNumber(){
        return mobNumber;
    }
    public String getEmail(){
        return email;
    }
    public String getSex(){
        return sex;
    }

    //the setter methods of the variable

    public void setName(String name){
        this.name = name;

    }
    public void setSurName(String surName ){
        this.surName = surName;
    }
    public void setBirthYear(String birthYear){
        this.DOB = DOB;
    }
    public void setMobNumber(String mobNumber){
        this.mobNumber = mobNumber;
    }
    public void setEmail(String email){
        this.email = email;
    }
    public void setSex(String sex){
        this.sex = sex;
    }





    public String toString(){
        return name+" "+surName+" "+DOB+""+mobNumber;
    }
}

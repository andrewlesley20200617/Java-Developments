import java.io.IOException;

public interface SkinConsultationManager {

    void addDoc();
    void deleteDoc();
    void printDoc();
    void saveList() throws IOException;

}

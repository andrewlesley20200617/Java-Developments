import java.io.*;
import java.util.Scanner;



public class Main {
    public static void main(String[] args) throws IOException, ClassNotFoundException {



        //scanner class to get input from the user
        Scanner input = new Scanner(System.in);
        WestminsterSkinConsultationManager console = new WestminsterSkinConsultationManager();


        try {
            console.loadList(); // the list is being loaded to display the existing doctors in the system
        } catch (FileNotFoundException e) {
            System.out.println("\n--------There are no doctors in the list-----------\n"); // if no doctors are saved in the system then this will be displayed.
        }


        String userInput;
        while(true){
            //the console to ask the user their desired input
            System.out.println("\n---------------Enter the desired input to access a certain system---------------\n");
            System.out.println("Enter 1 to add a doctor");
            System.out.println("Enter 2 to delete a doctor");
            System.out.println("Enter 3 to print the doctors list sorted by their surname");
            System.out.println("Enter 4 to save the list in a file");
            System.out.println("Enter 5 to open the GUI");
            System.out.println("Enter 0 to end program\n");
            System.out.print("Your input: ");

            userInput = input.nextLine();

            //the condition to direct the user to their desired input
            switch (userInput) {

                case ("1"):
                   console.addDoc();
                    continue;
                case ("2"):
                    console.deleteDoc();
                    continue;
                case ("3"):
                    console.printDoc();
                    continue;
                case ("4"):
                   console.saveList();
                    continue;
                case ("5"):
                    System.out.println("OPENING GUI");
                    console.GUI();
                    continue;
                case ("0"):
                    System.out.println("The program has been ended with the user's consent"); // if the user deisres to exit the program this will be performed
                    System.exit(1);
                default:
                    System.out.println("The input entered in incorrect please try again.");// if the user enters an incorrect input the loop will continue
                    continue;

            }




        }
    }
}
